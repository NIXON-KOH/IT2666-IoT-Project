﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using Windows.ApplicationModel.Background;


using System.Diagnostics;
using System.Threading.Tasks;
using GrovePi;
using GrovePi.Sensors;

// The Background Application template is documented at http://go.microsoft.com/fwlink/?LinkID=533884&clcid=0x409

namespace Huehue
{
    public sealed class StartupTask : IBackgroundTask
    {
        Pin light = Pin.AnalogPin0;
        Pin water = Pin.AnalogPin1;
        Pin temp = Pin.AnalogPin2;

        ILed LedRed = DeviceFactory.Build.Led(Pin.DigitalPin2);
        ILed LedGreen = DeviceFactory.Build.Led(Pin.DigitalPin3);
        Pin buzzer = Pin.DigitalPin4;

        IUltrasonicRangerSensor ultrasonic = DeviceFactory.Build.UltraSonicSensor(Pin.DigitalPin5);

        private int distance = 400;
        int sensorDistance;
        int DistanceThreshold = 5000;
        int moistureADCValue = 1023;
        private int sensorMoistureAdcValue;
        double temperature = 23;
        double sensortemp;

        private static SerialComms uartComms;
        private static string strRfidDetected = "";
        bool red, green;

        DataComms dataComms;
        string strDataRecieved = "";

        public void commsDataRecieve(string dataReceived)
        {
            try
            {
                strDataRecieved = dataReceived;       
                // E.g "RED=ON,GREEN=OFF"
                string[] ledlights = strDataRecieved.Split(',');

                string ledred = ledlights[0];
                if (ledred.Contains("ON")){
                    changeLed(LedRed, true);
                    activateBuzzer(buzzer, 80);
                    red = true;
                }else { changeLed(LedRed, false); red = false; }

                string ledgreen = ledlights[1];
                if (ledgreen.Contains("ON"))
                {
                    green = true;
                    activateBuzzer(buzzer, 0);
                    changeLed(LedGreen, true);
                }
                else {
                    green = false;
                    changeLed(LedGreen, false); }
            }
            catch (Exception)
            {
                Debug.WriteLine("Did you Forget initComms?");
            }
        }

        private void sendDataToWindows(string strDataOut)
        {
            try
            {
                dataComms.sendData(strDataOut);
                
            }
            catch (Exception)
            {
                Debug.WriteLine("Send Error. Initcomms?");
            }
        }

        private void initComms()
        {
            dataComms = new DataComms();
            dataComms.dataReceiveEvent += new DataComms.DataReceivedDelegate(commsDataRecieve);
        }

        static void uartDataHandler(object sender, SerialComms.UartEventArgs e)
        {
            strRfidDetected = e.data;
        }
        private void startuart()
        {
            uartComms = new SerialComms();
            uartComms.UartEvent += new SerialComms.UartEventDelegate(uartDataHandler);
        }

        private int readtempadc()
        {
            sm.WaitOne();
            int val = DeviceFactory.Build.GrovePi().AnalogRead(temp);
            sm.Release();
            return val;
        }
        private double gettemp()
        {
            int adcValue;
            double tempCalculated = 0, R;
            adcValue = readtempadc();
            int B = 4250, R0 = 100000;
            R = R0 * (1023.0 - adcValue) / adcValue;
            tempCalculated = 1 / (Math.Log(R / R0) / B + 1 / 298.15) - 273.15;
            if (!Double.IsNaN(tempCalculated) && tempCalculated > 15 && tempCalculated < 40)
            {
                temperature = tempCalculated;
            }
            return temperature;


        }

        private int getmoisture()
        {
            int adcValue;

            sm.WaitOne();
            adcValue = DeviceFactory.Build.GrovePi().AnalogRead(water);
            sm.Release();
            if (adcValue <= 1023)
            {
                moistureADCValue = adcValue;
            }
            return moistureADCValue;
        }
        private int getDistance()
        {
            sm.WaitOne();
            int distanceRead = ultrasonic.MeasureInCentimeters();
            sm.Release();

            if (distanceRead > 0)
            {
                sensorDistance = distanceRead;
            }
            return sensorDistance;
        }

        private System.Threading.Semaphore sm = new System.Threading.Semaphore(1, 1);

        private void activateBuzzer(Pin pin, byte val)
        {
            sm.WaitOne();
            DeviceFactory.Build.GrovePi().AnalogWrite(pin, val);
            sm.Release();
        }
        private void sleep(int ms)
        {
            Task.Delay(ms).Wait();
        }
        private void alarm()
        {
            activateBuzzer(buzzer, 50);
            sleep(10);
            activateBuzzer(buzzer, 0);
        }


        //Three Modes

        private int GetLightValue(Pin pin)
        {
            sm.WaitOne();
            int value = DeviceFactory.Build.GrovePi().AnalogRead(pin);
            sm.Release();

            return value;
        }


        private bool getLed(ILed led)
        {
            sm.WaitOne();
            SensorStatus sensorState = led.CurrentState;
            sm.Release();
            bool ledstate;
            switch (sensorState)
            {
                case SensorStatus.On: ledstate = true; break;
                case SensorStatus.Off: ledstate = false; break;
                default: ledstate = false; Debug.WriteLine("Problem with getLed(). Please Fix."); break;
            }

            return ledstate;
        }
        private void changeLed(ILed led, bool ledState)
        {
            SensorStatus targetState;
            switch (ledState)
            {
                case true: targetState = SensorStatus.On; break;
                case false: targetState = SensorStatus.Off; break;
                default: targetState = SensorStatus.Off; Debug.WriteLine("Problem with changeLed(). Please Fix."); break;
            }
            sm.WaitOne();
            led.ChangeState(targetState);
            sm.Release();
        }
       
        public void Run(IBackgroundTaskInstance taskInstance)
        {
            initComms();
            string sendData;
            int adcValue_Light = 0;
            startuart();
            changeLed(LedGreen, true);
            while (true)
            {
                adcValue_Light = GetLightValue(light);
                sensorDistance = getDistance();
                sensorMoistureAdcValue = getmoisture();
                sensortemp = gettemp();
                sensortemp.ToString("N2");
                red = getLed(LedRed);
                green = getLed(LedGreen);
                Debug.WriteLine($"{adcValue_Light} {sensorDistance} {sensorMoistureAdcValue} {sensortemp} {red} {green}");

                sendData = $"Bin=1, Light={adcValue_Light}, Water={sensorMoistureAdcValue},Temp={sensortemp}, Distance={sensorDistance}, Red={red}, Green={green}, RFID={strRfidDetected}";
                sendDataToWindows(sendData);

                if (!strRfidDetected.Equals(""))
                {
                    Debug.WriteLine(strRfidDetected);
                }


                

                
                strRfidDetected = "";
                

            }
        }
    }
}
